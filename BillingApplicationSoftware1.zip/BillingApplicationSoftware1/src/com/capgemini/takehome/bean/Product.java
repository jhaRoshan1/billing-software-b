package com.capgemini.takehome.bean;

public class Product {
private int productId;
private String productName;
 private  String Category;
 private  int Price;
public Product() {
	super();
}

public Product(int productId, String productName, String category, int price) {
	super();
	this.productId = productId;
	this.productName = productName;
	Category = category;
	Price = price;
}

public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getCategory() {
	return Category;
}

public void setCategory(String category) {
	Category = category;
}
public int getPrice() {
	return Price;
}
public void setPrice(int price) {
	Price = price;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((Category == null) ? 0 : Category.hashCode());
	result = prime * result + Price;
	result = prime * result + productId;
	result = prime * result + ((productName == null) ? 0 : productName.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Product other = (Product) obj;
	if (Category == null) {
		if (other.Category != null)
			return false;
	} else if (!Category.equals(other.Category))
		return false;
	if (Price != other.Price)
		return false;
	if (productId != other.productId)
		return false;
	if (productName == null) {
		if (other.productName != null)
			return false;
	} else if (!productName.equals(other.productName))
		return false;
	return true;
}

@Override
public String toString() {
	return "Product [productId=" + productId + ", productName=" + productName + ", Category=" + Category + ", Price="
			+ Price + "]";
}


}
