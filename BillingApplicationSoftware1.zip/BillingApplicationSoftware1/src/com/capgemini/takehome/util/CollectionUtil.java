package com.capgemini.takehome.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;

public class CollectionUtil {
	public static Map<Integer, Product>products=new HashMap<>();
	static{
		products.put(1001, new Product(1001, "iphone", "electronics", 35000));
		products.put(1002, new Product(1002, "ledtv", "electronics", 45000));
		products.put(1003, new Product(1003, "teddy", "toys",800));
		products.put(1004, new Product(1004, "telescope", "toys",5000));
	}
}
