package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductService{

	IProductDAO iproductdao=new ProductDAO();
	@Override
	public Product getProductDetails(int productCode) {
	Product product=iproductdao.getProductDetails(productCode);
	return product;
	}
	@Override
	public int calculateLineTotal(int Price, int pQuantity) {
		int lineTotal=Price*pQuantity;
		return lineTotal;
	}

}
