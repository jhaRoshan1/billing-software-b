package com.capgemini.takehome.exceptions;

public class ProductNotValidException extends Exception {
public ProductNotValidException(){
	System.out.println("product not found");
}
}
