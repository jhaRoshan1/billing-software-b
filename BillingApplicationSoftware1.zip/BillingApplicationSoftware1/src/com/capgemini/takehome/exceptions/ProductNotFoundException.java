package com.capgemini.takehome.exceptions;

public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(int productId) {
		System.out.println("sorry! the product code"+productId+"is not available");
	}
}