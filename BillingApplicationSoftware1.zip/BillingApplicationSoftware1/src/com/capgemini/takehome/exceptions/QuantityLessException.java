package com.capgemini.takehome.exceptions;

public class QuantityLessException extends Exception {
public QuantityLessException(int pQuantity )
{
	System.out.println("product quantity"+pQuantity+"is invalid");
}
}
