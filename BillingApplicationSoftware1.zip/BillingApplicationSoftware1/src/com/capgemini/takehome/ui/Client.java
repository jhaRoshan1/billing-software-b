package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.exceptions.ProductNotFoundException;
import com.capgemini.takehome.exceptions.ProductNotValidException;
import com.capgemini.takehome.exceptions.QuantityLessException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1:Generate Bill by entering product code and quantity \n 2:Exit");
		    System.out.println("enter your choice");
		    int ch=sc.nextInt();
		    
		    switch(ch)
		    {
		    case 1:System.out.println("enter product details");
		    System.out.println("enter product code");
		    int productId=sc.nextInt();
		   
				try {
					 if(productId<1000||productId>9999)
					throw new ProductNotFoundException(productId);
				} catch (ProductNotFoundException e) {
					
					System.out.println(e.getMessage());
				}
			System.out.println("enter quantity");
			int pQuantity=sc.nextInt();
			
				try {
					if(pQuantity<=0)
					throw new QuantityLessException(pQuantity);
				} catch (QuantityLessException e) {
					System.out.println(e.getMessage());
				}
				IProductService services=new ProductService();
					try {
						if(services.getProductDetails(productId)==null)
						throw new ProductNotValidException();
						else
							services.getProductDetails(productId);
					} catch (ProductNotValidException e) {
						
				      System.out.println(e.getMessage());
					}break;
					
		    case 2:System.exit(0);
		    default:System.out.println("wrong choice");
		    }
		
		}

	}

}
